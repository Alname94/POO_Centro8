package com.alejomendez.java.actividad1.tests;

import com.alejomendez.java.actividad1.entidades.AutoClasico;
import com.alejomendez.java.actividad1.entidades.AutoNuevo;
import com.alejomendez.java.actividad1.entidades.Colectivo;
import com.alejomendez.java.actividad1.entidades.Radio;

public class TestVehiculo {
    public static void main(String[] args) {
        System.out.println("*** TEST DE LA CLASE Radio ***");

        Radio radio1 = new Radio("X-View", 100);
        Radio radio2 = new Radio("JBL", 20);
        Radio radio3 = new Radio("Pioneer", 85);

        System.out.println(radio1);
        System.out.println(radio2);
        System.out.println(radio3);

        System.out.println("--------------------------------------");
        
        System.out.println("** TEST DE LA CLASE AutoNuevo ***");
        
        AutoNuevo autoNuevo1 = new AutoNuevo("Negro", "Ford", "Mondeo", "JVC", 30);
        autoNuevo1.informarTipoVehiculo();
        Radio radio4 = autoNuevo1.agregarRadio("Sony", 55);
        System.out.println(autoNuevo1.getRadio());
        autoNuevo1.cambiarRadio(radio3);
        System.out.println(autoNuevo1.getRadio());
        autoNuevo1.cambiarRadio(radio4);
        System.out.println(radio3);

        System.out.println("--------------------------------------");
        
        System.out.println("** TEST DE LA CLASE Colectivo ***");

        Colectivo colectivo1 = new Colectivo("azul", "Mercedez benz", "bondi");
        colectivo1.informarTipoVehiculo();
        colectivo1.agregarRadio("Bose", 323);
        colectivo1.cambiarRadio(radio4);
        colectivo1.cambiarRadio(radio3);
        System.out.println(colectivo1.getRadio());

        System.out.println("--------------------------------------");
        
        System.out.println("** TEST DE LA CLASE AutoClasico ***");

        AutoClasico autoClasico1 = new AutoClasico("Blanco", "Ford", "Galaxy");
        autoClasico1.informarTipoVehiculo();
        autoClasico1.cambiarRadio(radio3);
        Radio radio5 = autoClasico1.agregarRadio("Sansui", 50);
        System.out.println(radio5);
        autoClasico1.cambiarRadio(radio5);
        autoClasico1.cambiarRadio(radio2);
        






        
        
        

    }
}
