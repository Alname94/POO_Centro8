package com.alejomendez.java.actividad1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlejomendezActividad1RelacionesentreclasesApplicationTests {

	@Test
	void contextLoads() {
	}

}
