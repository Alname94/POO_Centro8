package com.alejomendez.java.actividad1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlejomendezActividad1RelacionesentreclasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlejomendezActividad1RelacionesentreclasesApplication.class, args);
	}

}
