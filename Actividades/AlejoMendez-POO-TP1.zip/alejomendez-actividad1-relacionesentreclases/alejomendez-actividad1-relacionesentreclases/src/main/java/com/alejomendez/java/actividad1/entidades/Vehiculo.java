package com.alejomendez.java.actividad1.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
// - No existen instancias puras de Vehículo
public abstract class Vehiculo {
    private String color;
    private String marca;
    private String modelo;
    private double precio;
    
    
    
    public Vehiculo (String color, String marca, String modelo){
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    public abstract void informarTipoVehiculo();

    public abstract Radio agregarRadio(String marcaRadio, int potenciaWatts);
    
    public abstract void cambiarRadio(Radio radio);
    

}
