package com.alejomendez.java.actividad1.entidades;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Radio {
    private String marcaRadio;
    private int potenciaWatts;
    private boolean radioConectada;

    public Radio (String marcaRadio, int potenciaWatts){
        this.marcaRadio = marcaRadio;
        this.potenciaWatts = potenciaWatts;
        this.radioConectada=false;
    }
}
