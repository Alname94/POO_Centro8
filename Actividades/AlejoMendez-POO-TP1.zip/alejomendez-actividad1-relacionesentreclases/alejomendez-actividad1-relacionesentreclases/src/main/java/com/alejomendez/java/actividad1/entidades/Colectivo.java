package com.alejomendez.java.actividad1.entidades;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper=true)
// - No se pueden crear subproductos derivados del Colectivo.
public final class Colectivo extends Vehiculo {
    @Setter(AccessLevel.NONE)
    private Radio radio;
    

    public Colectivo(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    @Override
    public void informarTipoVehiculo() {
        System.out.println("Hola soy un colectivo");
    }

    @Override
    public Radio agregarRadio(String marcaRadio, int potenciaWatts) {
        return new Radio(marcaRadio, potenciaWatts);
    }

    @Override
    public void cambiarRadio(Radio radio) {
        if(!radio.isRadioConectada()){
            if(this.radio==null){
                this.radio = radio;
                radio.setRadioConectada(true);
                System.out.println("Ha sido conectada la " + radio);
             }
             else{
                this.radio.setRadioConectada(false);
                System.out.println("Desconectando: " + this.radio);
                this.radio = radio;
                radio.setRadioConectada(true);
                System.out.println("Ha sido conectada la " + radio);
             }
        }else {
            System.out.println("error, esa radio ya está en uso");
        }
    }
}
