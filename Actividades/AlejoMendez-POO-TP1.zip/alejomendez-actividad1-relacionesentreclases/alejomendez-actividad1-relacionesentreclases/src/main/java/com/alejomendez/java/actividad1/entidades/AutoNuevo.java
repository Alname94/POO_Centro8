package com.alejomendez.java.actividad1.entidades;

import io.micrometer.common.lang.NonNull;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)
public class AutoNuevo extends Vehiculo{
    @NonNull
    @Setter(AccessLevel.NONE)
    private Radio radio;
    
    // - Un Auto Nuevo siempre tiene Radio
    //constructor de AutoNuevo con objeto de la clase Radio obligatorio
    //por lo tanto desde la construcción, la radio va a estar conectada
    public AutoNuevo(String color, String marca, String modelo, String marcaRadio, int potenciaWatts) {
        super(color, marca, modelo);
        this.radio = new Radio(marcaRadio, potenciaWatts);
        radio.setRadioConectada(true);
    }

    @Override
    public void informarTipoVehiculo() {
        System.out.println("Hola, soy un auto nuevo");
    }

    @Override
    public Radio agregarRadio(String marcaRadio, int potenciaWatts) {
        return new Radio(marcaRadio, potenciaWatts);
    }

    // - Se puede cambiar de Radio.
    // - Una Radio solo puede estar en un Vehículo a la vez.
    /**
     * Este método permite cambiar el objeto radio de un vehículo
     * Realiza una verificación, 
     * si la radio que pasamos como parámetro no está conectada en otro vehículo,
     * primero "desconecta" la radio en caso que haya una siendo utilizada,
     * segundo, asigna el valor de la radio pasada como parámetro al espacio libre de radio del vehículo
     * y por último la "conecta".
     * En caso de que la radio pasada como parámetro se encuentre siendo utilizada por otro vehículo,
     * arroja un mensaje de error. 
    */
    @Override
    public void cambiarRadio(Radio radio) {        
        if(!radio.isRadioConectada()){
            this.radio.setRadioConectada(false);
            System.out.println("Desconectando: " + this.radio);
            this.radio = radio;
            radio.setRadioConectada(true);
            System.out.println("Ha sido conectada la " + radio);        
        }else {
            System.out.println("error, esa radio ya está en uso");
        }
    }


}
